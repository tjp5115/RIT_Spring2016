#pragma once
class ViewPlane
{
public:
	ViewPlane(){};

	int h;
	int w;
	float pixel_size;
};

